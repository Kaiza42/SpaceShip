//
//  SpacyshooterApp.swift
//  Spacyshooter
//
//  Created by Apprenant 87 on 21/09/2024.
//

import SwiftUI

@main
struct MiniJeuu: App {
    var body: some Scene {
        WindowGroup {
            miniJeuOtionel()
        }
    }
}
